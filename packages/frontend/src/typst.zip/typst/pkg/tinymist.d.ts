/* tslint:disable */
/* eslint-disable */

export class IndividualLanguages {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readonly code: string;
  readonly name: string;
}

export class LanguageCode {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readonly individual_languages: Array<any>;
  readonly code: string;
  readonly name: string;
  readonly code_3: string;
  readonly code_2b: string;
  readonly code_2t: string;
}

export class ProxyContext {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Creates a new `ProxyContext` instance.
   */
  constructor(context: any);
  /**
   * A convenience function to untar a tarball and call a callback for each
   * entry.
   */
  untar(data: Uint8Array, cb: Function): void;
  /**
   * Returns the JavaScript this.
   */
  readonly context: any;
}

export class TinymistLanguageServer {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Handles incoming requests.
   */
  on_request(method: string, js_params: any): any;
  /**
   * Handles incoming responses.
   */
  on_response(js_result: any): void;
  /**
   * Handles incoming notifications.
   */
  on_notification(method: string, js_params: any): void;
  /**
   * 编译文档并等待返回最新 diagnostics。
   *
   * 注意：真正的 diagnostics 仍会通过 LSP 标准的 `textDocument/publishDiagnostics`
   * 异步推送给前端；此方法只是为了“触发编译 + 等到一轮 diagnostics”，方便 WASM 场景
   * 里做 pull-style 调用。
   */
  compile_document(uri: string, content: string): any;
  /**
   * Handles preview messages.
   */
  on_preview_message(task_id: string, message: any): void;
  /**
   * Creates a new language server.
   */
  constructor(init_opts: any);
  /**
   * Get the version of the language server.
   */
  static version(): string;
  /**
   * Handles internal events.
   */
  on_event(event_id: number): void;
}

export function from_code_1(code: string): LanguageCode | undefined;

export function from_code_2b(code: string): LanguageCode | undefined;

export function from_code_2t(code: string): LanguageCode | undefined;

export function from_code_3(code: string): LanguageCode | undefined;

/**
 * Gets the long version description of the library.
 */
export function version(): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_tinymistlanguageserver_free: (a: number, b: number) => void;
  readonly tinymistlanguageserver_compile_document: (a: number, b: number, c: number, d: number, e: number) => any;
  readonly tinymistlanguageserver_new: (a: any) => [number, number, number];
  readonly tinymistlanguageserver_on_event: (a: number, b: number) => void;
  readonly tinymistlanguageserver_on_notification: (a: number, b: number, c: number, d: any) => void;
  readonly tinymistlanguageserver_on_preview_message: (a: number, b: number, c: number, d: any) => void;
  readonly tinymistlanguageserver_on_request: (a: number, b: number, c: number, d: any) => any;
  readonly tinymistlanguageserver_on_response: (a: number, b: any) => void;
  readonly tinymistlanguageserver_version: () => [number, number];
  readonly version: () => [number, number];
  readonly __wbg_individuallanguages_free: (a: number, b: number) => void;
  readonly __wbg_languagecode_free: (a: number, b: number) => void;
  readonly from_code_1: (a: number, b: number) => number;
  readonly from_code_2b: (a: number, b: number) => number;
  readonly from_code_2t: (a: number, b: number) => number;
  readonly from_code_3: (a: number, b: number) => number;
  readonly individuallanguages_code: (a: number) => [number, number];
  readonly individuallanguages_name: (a: number) => [number, number];
  readonly languagecode_code: (a: number) => [number, number];
  readonly languagecode_code_2b: (a: number) => [number, number];
  readonly languagecode_code_2t: (a: number) => [number, number];
  readonly languagecode_code_3: (a: number) => [number, number];
  readonly languagecode_individual_languages: (a: number) => any;
  readonly languagecode_name: (a: number) => [number, number];
  readonly __wbg_proxycontext_free: (a: number, b: number) => void;
  readonly proxycontext_context: (a: number) => any;
  readonly proxycontext_untar: (a: number, b: number, c: number, d: any) => [number, number];
  readonly proxycontext_new: (a: any) => number;
  readonly qcms_profile_precache_output_transform: (a: number) => void;
  readonly lut_inverse_interp16: (a: number, b: number, c: number) => number;
  readonly lut_interp_linear16: (a: number, b: number, c: number) => number;
  readonly qcms_enable_iccv4: () => void;
  readonly qcms_profile_is_bogus: (a: number) => number;
  readonly qcms_transform_data_bgra_out_lut: (a: number, b: number, c: number, d: number) => void;
  readonly qcms_transform_data_bgra_out_lut_precache: (a: number, b: number, c: number, d: number) => void;
  readonly qcms_transform_data_rgb_out_lut: (a: number, b: number, c: number, d: number) => void;
  readonly qcms_transform_data_rgb_out_lut_precache: (a: number, b: number, c: number, d: number) => void;
  readonly qcms_transform_data_rgba_out_lut: (a: number, b: number, c: number, d: number) => void;
  readonly qcms_transform_data_rgba_out_lut_precache: (a: number, b: number, c: number, d: number) => void;
  readonly qcms_transform_release: (a: number) => void;
  readonly qcms_white_point_sRGB: (a: number) => void;
  readonly wasm_bindgen_807c5274271c0350___convert__closures_____invoke___wasm_bindgen_807c5274271c0350___JsValue_____: (a: number, b: number, c: any) => void;
  readonly wasm_bindgen_807c5274271c0350___closure__destroy___dyn_core_47d47fedbfd2fbc8___ops__function__FnMut__wasm_bindgen_807c5274271c0350___JsValue____Output_______: (a: number, b: number) => void;
  readonly wasm_bindgen_807c5274271c0350___convert__closures_____invoke___wasm_bindgen_807c5274271c0350___JsValue__wasm_bindgen_807c5274271c0350___JsValue_____: (a: number, b: number, c: any, d: any) => void;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_exn_store: (a: number) => void;
  readonly __externref_table_alloc: () => number;
  readonly __wbindgen_externrefs: WebAssembly.Table;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __externref_table_dealloc: (a: number) => void;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
